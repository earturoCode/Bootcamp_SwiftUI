import UIKit
import Alamofire

class AutServices {
    
    func loginAccount(email: String, pass: String) async {
        let url = "https://lvmybcyhrbisfjouhbrx.supabase.co/auth/v1/signup"
        let modeloRegister = ModeloRegister(email: email, password: pass)
        let headers: HTTPHeaders = [
            "apikey": constants.apikey,
            "Content-Type": "application/json"
        ]
        
        do {
            let response = try await AF.request(url,
                                                method: .post,
                                                parameters: modeloRegister,
                                                encoder: JSONParameterEncoder.default,
                                                headers: headers)
                .serializingDecodable(ModeloLoginResponse.self).value
            
            print("Token: \(response.acces_token)")
            print("User ID: \(response.user.id)")
            
        } catch {
            print("Error durante el registro: \(error.localizedDescription)")
        }
    }
    func login(email: String, pass: String) async {
        let url = "https://lvmybcyhrbisfjouhbrx.supabase.co/auth/v1/token?grant_type=password"
        let modeloLogin = ModeloRegister(email: email, password: pass) // mismo modelo que para registro

        let headers: HTTPHeaders = [
            "apikey": constants.apikey,
            "Content-Type": "application/json"
        ]

        do {
            let response = try await AF.request(url,
                                                method: .post,
                                                parameters: modeloLogin,
                                                encoder: JSONParameterEncoder.default,
                                                headers: headers)
                .serializingDecodable(ModeloLoginResponse.self).value

            print("Login exitoso")
            print("Token: \(response.acces_token)")
            print("User ID: \(response.user.id)")

        } catch {
            print("Error durante el login: \(error.localizedDescription)")
        }
    }

    
}

struct ModeloLoginResponse: Decodable {
    let acces_token: String
    let user: User
}

struct User: Decodable {
    let id: String
}

struct ModeloRegister: Encodable {
    let email: String
    let password: String
}
